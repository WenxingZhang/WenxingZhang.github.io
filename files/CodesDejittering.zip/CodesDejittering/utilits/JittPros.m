function Jitu = JittPros(u,S,flagBD)
%%%%%%%%%%
% The function implement the jittering processing to an image
% Note: for RGB image, the jittering on each channel are the same
% flagBD  --- boundary conditon. 
%            0: zero boundary
%            1: circular boundary 
%            2: replicate boundary 
%            3: symmetric boundary

%% Translate each pixels u along vector s=(s_1,s_2)

S1 = S(:,:,1);  S2 = S(:,:,2);

if nargin<4; flagBD=3; end

[n1,n2,n3]= size(u);
for i=1:n3
    Jitu(:,:,i) = TSL(u(:,:,i),S1,S2,flagBD);     
end





function Ru = TSL(u,S1,S2,flagBD)
%%%%%%%%%%%% make the line jitter for 2D grayimage 
[n1,n2,n3]= size(u);
Ms   = 25;
switch flagBD
    case 0  %%% zero boundary 
        Elu  = padarray(u,[0,Ms]);
    case 1  %%% period boundary 
        Elu  = padarray(u,[0,Ms],'circular'); 
    case 2  %%% replicate boundary
        Elu= padarray(u,[0,Ms],'replicate'); 
    case 3  %%% symmetric boundary
        Elu= padarray(u,[0,Ms],'symmetric'); 
end

ES1= padarray(S1,[0,Ms]);
ES2= padarray(S2,[0,Ms]);
[en1,en2] = size(Elu);
[X,Y]= meshgrid(1:en2,1:en1);
Xn   = X+ES1; Yn = Y+ES2;
Tu   = interp2(X,Y,Elu,Xn,Yn,'*cubic',0);  
% Tu   = interp2(X,Y,Elu,Xn,Yn,'*nearest',1);  
Ru = Tu(:,Ms+1:n2+Ms);








