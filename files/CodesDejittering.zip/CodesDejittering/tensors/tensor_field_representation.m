function phi=tensor_field_representation(im,eig1,eig2,val1,val2,Cx,Cy,step)
%function phi=tensor_field_representation(im,eig1,eig2,val1,val2,Cx,Cy,step,h)
%   this function computes the ellipsoid representation of the 2D structure tensor
%   field.
%
%   INPUT: 
%   eig1,eig2: the two eigenvectors of the 2D structure tensor field. those
%   eigenvectors are n by m by 2 matrices,
%
%   val1,val2: the two eigenvalues of the 2D structure tensor field. Those
%   eigenvalues are n by m matrices,
%
%   Cx,Cy: are the mesh corresponding to the image,
%
%   step: this function doesn't plot ellipsoid oneach coordonate (Cx,Cy) 
%   but plots one every step coordonate.
% 
     
    val1=val1(1:step:end,1:step:end);
    val2=val2(1:step:end,1:step:end);

    Cx=Cx(1:step:end,1:step:end);
    Cy=Cy(1:step:end,1:step:end);

    phi=find_angle(eig2);
    phi=-phi(1:step:end,1:step:end);

    nval=sqrt(val1.^2+val2.^2);
    val1=val1./nval;
    val2=val2./nval;

    ad_ellipse(step/2*val2(:),step/2*val1(:),phi(:),Cx(:),Cy(:),'r');
    plot(Cx(:),Cy(:),'r.','markersize',3)
end