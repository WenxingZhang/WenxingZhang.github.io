function J_rho=structure_tensor(im,sig,rho)
%   This function computes the structure tensor matrix associated to the 
%   image im.
%   
%   INPUT:
%   im: m x n matrix corresponding to the image
%   sig: standard deviation (in pixels) of the Gaussian kernel
%          applied to the image
%   rho: the standard deviation (in pixels) of the Gaussian kernel applied 
%   to the strcture tensor to average the directions of the eigenvectors.
%
%   OUTPUT:
%   J_rho: the structure tensor a 2*n by 2*m matrix. T_rho is a 4 blocks 2D 
%   matrix [A1,A2;A3,A4] each block of size n by m. For example, the first 
%   block should contain the first component of the structure tensor for 
%   each pixel of the image.
%   grad: the gradient matrix associated to the image. n x m x 2 matrix.
%   grad(:,:,1) is the fist component of the gradient vector for each pixel
%   of the image.

% %  Written by Wenxing Zhang, Omar Dounia and Pierre Weiss, 
% %  ITAV, Toulouse, France, July 2014.
% %  Troubleshooting: wenxing84@gmail.com, pierre.armand.weiss@gmail.com


    % Gaussian kernel convolution applied to the image 
        [nx,ny]=size(im);
        if sig==0
            im_sig=im; 
        else
            gk_sig=gaussian_kernel(ny,nx,sig);      
            im_sig=ifft2(fft2(gk_sig).*fft2(im));   
        end
    % In order to find parallel structures we need to replace the gradient by
    % its tensor product so that the structure descriptor is invariant under
    % sign changes:    
%     grad=gradient(im_sig);    %%% gradient A:   

       grad = zeros(nx,ny,2);  %%% gradient B:        
       h = [-3 0 3; -10 0 10; -3 0 3]/32;   
       grad(:,:,1) = imfilter(im_sig,h','symmetric'); 
       grad(:,:,2) = imfilter(im_sig,h,'symmetric'); 
        
%         grad = zeros(nx,ny,2);        %%% gradient C:
%         G=RotVarGradient(2,3);
%         grad(:,:,1) = real(imfilter(im_sig,-G.Gy,'symmetric')); 
%         grad(:,:,2) = real(imfilter(im_sig,-G.Gx,'symmetric')); 
%         
        
        %%%%%%% contrast invariant
        Tensor = zeros(nx,ny,4);
        Tensor(:,:,1)= grad(:,:,1).^2; 
        Tensor(:,:,2)= grad(:,:,1).*grad(:,:,2);
        Tensor(:,:,3)= Tensor(:,:,2);
        Tensor(:,:,4)= grad(:,:,2).^2;        
        
        clear im gk_sig im_sig grad
        gk_rho = gaussian_kernel(ny,nx,rho);
        J_rho  = zeros(size(Tensor));
        Fgk_rho= fft2(gk_rho);
        J_rho(:,:,1) = real(ifft2(Fgk_rho.*fft2(Tensor(:,:,1))));
        J_rho(:,:,2) = real(ifft2(Fgk_rho.*fft2(Tensor(:,:,2))));
        J_rho(:,:,3) = J_rho(:,:,2);
        J_rho(:,:,4) = real(ifft2(Fgk_rho.*fft2(Tensor(:,:,4))));      
                
end