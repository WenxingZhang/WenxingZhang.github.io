function grad=gradient(u)
%function grad=gradient(u)
%   this function computes the 2D gradient of a 2D image u. grad is a
% %   size(u) by 2 matrix.
%     [nx,ny]=size(u);
%     grad=zeros(nx,ny,2);
%     grad(1:end-1,:,1)=u(2:end,:)-u(1:end-1,:);
%     grad(:,1:end-1,2)=u(:,2:end)-u(:,1:end-1);
%     
    [n1,n2]=size(u);
    grad=zeros(n1,n2,2);
    grad(:,:,1) = [u(2:n1,:,:)-u(1:n1-1,:,:); u(1,:,:)-u(n1,:,:)]; %%\nabla_1 x 
    grad(:,:,2)=[u(:,2:n2,:)-u(:,1:n2-1,:), u(:,1,:)-u(:,n2,:)]; %%\nabla_2 y

    
    
    
end