
function outs = Solver_StruTensorV2(u0,h,ind,opts)

%%% ADMM for solving diffusion tensor model.
%%% min tau \phi(\nabla u)+0.5\|P_A Hu-u0\|_2^2
%%% tau --- trade-off of model, \phi=sqrt{t^TDt}
%%%Inputs:
%%% u0  --- noise image
%%% h   --- blurry
%%% ind --- impulse set A (i.e., indicate the P_A operator)
%%% opts.tau  --- trade-off of model
%%% opts.beta --- penalty of ADMM
%%% opts.ksig --- local scale of structure tensor J_rho(\nabla u_\sigma^0)
%%% opts.krho --- average scale of structure tensor J_rho(\nabla u_\sigma^0)
%%% opts.arrEnha---'edge' for edge-enhancing; 'cohere' for coherence-enhancing 
[n1,n2,n3] = size(u0);
beta1 = opts.beta(1); beta2 = opts.beta(2); beta3 = opts.beta(3);
tau   = opts.tau; 
MaxIt = opts.MaxIt; 

%%% Periodic boundary condtion
siz = size(h);
center = [fix(siz(1)/2+1),fix(siz(2)/2+1)];
P  = zeros(n1,n2,n3); 
for i = 1:n3; P(1:siz(1),1:siz(2),i) = h; end
D  = fft2(circshift(P,1-center));
H  = @(x) real(ifft2(D.*fft2(x)));       %%%% Blur operator.  B x 
HT = @(x) real(ifft2(conj(D).*fft2(x))); %%%% Transpose of blur operator.
%%%%%%%%%%% Periodic boundary condtion %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
d1h = zeros(n1,n2,n3); d1h(1,1,:) = -1; d1h(n1,1,:) = 1; d1h = fft2(d1h);
d2h = zeros(n1,n2,n3); d2h(1,1,:) = -1; d2h(1,n2,:) = 1; d2h = fft2(d2h);
Px  = @(x) [x(2:n1,:,:)-x(1:n1-1,:,:); x(1,:,:)-x(n1,:,:)]; %%\nabla_1 x 
Py  = @(x) [x(:,2:n2,:)-x(:,1:n2-1,:), x(:,1,:)-x(:,n2,:)]; %%\nabla_2 y
PTx = @(x) [x(n1,:,:)-x(1,:,:); x(1:n1-1,:,:)-x(2:n1,:,:)]; %%\nabla_1^T x 
PTy = @(x) [x(:,n2,:)-x(:,1,:), x(:,1:n2-1,:)-x(:,2:n2,:)]; %%\nabla_2^T y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sig = opts.ksig;  %% mollifier k_\sigma
rho = opts.krho;  %% mollifier k_\rho
EigInfo = coherence_orientation(u0,sig,rho);

% [X,Y] = meshgrid(1:n1,1:n2);
%c = (X-129).^2+(Y-129).^2<3200;
%a = edge(opts.I); %b = bwmorph(a,'dilate',10)|c; 
%figure; imshow(b)
% nu1=EigInfo.nu1;  %nu1=nu1.*b;
% nu2=EigInfo.nu2;  %nu2=nu2.*b;

if strcmpi(opts.arrEnha,'edge')  %%%% Edge-enhancing diffusion tensor
    Cpar = opts.EnCpar;
    lbd1 = 1-exp(-Cpar./(EigInfo.nu1.^2+eps));  lbd2 = 1;
    v1   = EigInfo.w1;  v2 = EigInfo.w2;   
elseif strcmpi(opts.arrEnha,'cohere')        %%%% coherence-enhance
    alp  = opts.Enalp; Cpar = opts.EnCpar;
    kap  = (EigInfo.nu1-EigInfo.nu2).^2;
    lbd1 = alp;        lbd2= alp+(1-alp)*exp(-Cpar./(kap+eps));
    v1   = EigInfo.w1;  v2 = EigInfo.w2;  
else
    error('either [edge] or [cohere] enhance');
end

%%%%%%%%%%%%%%%%%% plot the anisotropic ellipses
% figure; imshow(1*ones(size(u0)),[],'border','tigh'); hold on; 
% tensor_field_representation(ones(size(u0)),v1,v2,nu1,nu2,X,Y,11,h); 
% axis([0 n1 0 n2]); hold on      
% 
% figure; imshow(1*ones(size(u0)),[],'border','tigh'); hold on; 
% tensor_field_representation(u0,v2,v1,lbd1,lbd2,X,Y,11); axis([0 n1 0 n2]);       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

slbd1 = sqrt(lbd1); slbd2 =sqrt(lbd2);
clear EigInfo 

figure(20); 
% subplot(221); imshow(lbd1); 
% title(['min:',num2str(min(lbd1(:))),'  max:',num2str(max(lbd1(:)))]);
% subplot(222); imshow(lbd2);
% title(['min:',num2str(min(lbd2(:))),'  max:',num2str(max(lbd2(:)))]);

%%%%Intionalization
y1  = zeros(n1,n2,n3);
y2  = zeros(n1,n2,n3);
z   = zeros(n1,n2,n3);
q11 = zeros(n1,n2,n3);
q12 = zeros(n1,n2,n3);
q2  = zeros(n1,n2,n3);
q31 = zeros(n1,n2,n3);
q32 = zeros(n1,n2,n3);

MDu  = beta2*abs(D).^2 + beta1*(abs(d1h).^2+abs(d2h).^2); 
Nind = ~ind;
PSNR = zeros(1,MaxIt);  
SSIM = zeros(1,MaxIt);  
clear  d1h d2h P

for k=1:MaxIt     
    
    %%%%%%%%%%% measurements: PSNR and SSIM  %%%%%%%%%%%%%%%%%%%%
    if k==1; u = u0; end;
    PSNR(k)  = psnr(u,opts.I);     %%% PSNR
    K = [0.05 0.05]; 
    L = 1;   window  = ones(8);    
    [mssim,ssim_map] = ssim_index(u,opts.I, K, window, L);
    SSIM(k) = mssim;
%     Obj(Itr)= tau*sum(tep(:))+0.5*norm(B(u)-u0,'fro')^2; 
%     ObjErr(Itr)= abs(Obj(Itr)-Objstar)/Objstar;
    
    if mod(k,100)==0
%         subplot(223); 
%         figure;         
        imshow(u,[]);
        title(['it:',num2str(k),', PSNR:',num2str(PSNR(k)),', SSIM:',num2str(SSIM(k))]);
        drawnow
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
     
    
    %%% step 1: \tilde u
    Temp= beta2*HT(z+u0+q2) + beta1*(PTx(y1+q11) + PTy(y2+q12));
    u   = real(ifft2(fft2(Temp)./MDu));
    
    %%% step 2: \tilde w
    sk1 = slbd1.*(v1(:,:,1).*y1+v1(:,:,2).*y2)-q31;
    sk2 = slbd2.*(v2(:,:,1).*y1+v2(:,:,2).*y2)-q32;    
    nsk = sqrt(sk1.^2+sk2.^2+eps); 
    nsk = max(1-tau./(beta3*nsk),0);
    w1  = nsk.*sk1;
    w2  = nsk.*sk2;
    
    %%% step 3: \tilde y 
    dxu  = Px(u);   
    dyu  = Py(u);
    CT1  = v1(:,:,1).*slbd1.*(w1+q31) + v1(:,:,2).*slbd2.*(w2+q32);
    CT2  = v2(:,:,1).*slbd1.*(w1+q31) + v2(:,:,2).*slbd2.*(w2+q32);
    Temp1= beta1*(dxu-q11) + beta3*CT1;
    Temp2= beta1*(dyu-q12) + beta3*CT2;
    sk1  = (v1(:,:,1).*Temp1 + v1(:,:,2).*Temp2)./(beta1+beta3*lbd1);
    sk2  = (v2(:,:,1).*Temp1 + v2(:,:,2).*Temp2)./(beta1+beta3*lbd2);
    y1   = v1(:,:,1).*sk1+v2(:,:,1).*sk2;
    y2   = v1(:,:,2).*sk1+v2(:,:,2).*sk2;
    
    Cy1  = slbd1.*(v1(:,:,1).*y1+v1(:,:,2).*y2);
    Cy2  = slbd2.*(v2(:,:,1).*y1+v2(:,:,2).*y2);
    
    
    %%% step 3: \tilde z
    Hu   = H(u);
    Temp = Hu-u0-q2;
    switch lower(opts.FdT)
        case 'l2'                   
            z = beta2*Temp./(Nind+beta2);  %%%%% L2 fidelity            
        case 'l1'            
            z = Temp - max(-1/beta2,min(Temp,1/beta2)); %%%%%% L1 fidelity
            z = ind.*z+Nind.*z; 
    end
    
    %%%%%%% update multiplier
    q11 = q11 -(dxu-y1);
    q12 = q12 -(dyu-y2);
    q2  = q2  -(Hu-z-u0);
    q31 = q31-(Cy1-w1);
    q32 = q32-(Cy2-w2);
    
end
outs.x  = u; outs.PSNR = PSNR;
outs.SSIM = SSIM; 

