%%% structure tensor based variational model for pixel-jitter image recovery
%%% This codes can test both gray and RGB images
%%% Written by Wenxing Zhang, 2021.09.04
%%% zhangwx@uestc.edu.cn

clc;
clear;
close all;
randn('state',0); rand('seed',0);
addpath utilits solvers Images tensors

%% %%%%%%%%%%%%%%% ideal image, scaled into [0,1] %%%%%%%%%
ImagName='SynCircles.png';    hsize = 1; Sig =1;  LU = 10;
% ImagName='peppers.png';     hsize = 9; Sig =5;   LU = 4;
% ImagName='boatpart.png';   hsize = 9; Sig =5; LU = 4;
% ImagName='fingerprintpart.png'; hsize = 9; Sig =5;  LU = 3;
% ImagName='baboonpart.png';     hsize = 9; Sig =5;  LU = 4;  
% ImagName='housergb.png';   hsize = 9; Sig =5;   LU = 4;
% ImagName='barbarapart.png'; hsize = 9; Sig =0.1;  LU = 1;

I = im2double(imread(ImagName));  
[n1,n2,n3] = size(I);

%% %%%%%% noise type and blur %%%%%% 
NoiseType = 'rv'; %%%% sp: salt-pepper; rv: random-valued
h = fspecial('gaussian',hsize,Sig);  %%% blur
Ib= imfilter(I,h,'circular');


%% %%%% jitter function and jitter image
S = random('unif',-LU,LU,n1,n2,2);  %% LU: maximal shift
xb = JittPros(Ib,S); 


for nRGB = 1:n3  %%%each channel in parallel manner
        
    %%%%%%%%%%% Phase I: adaptive filter
    %%% ind: noised pixels (as 1). Nind: P_A, noisefree pixels
    if strcmp(NoiseType,'sp');
        Window = 19;  [f,ind] = adpmedft(xb(:,:,nRGB),Window);
    else strcmp(NoiseType,'rv'); 
        IT = 2; f(:,:,nRGB) = xb(:,:,nRGB); 
        for i=1:IT; f(:,:,nRGB) = acwmf(f(:,:,nRGB),i); end;
        ind = (f(:,:,nRGB) ~= xb(:,:,nRGB));
    end
    
    %%%%%%%%% Phase II: anisotropic diffusion
    opts.FdT = 'l1';        opts.MaxIt = 300;
    opts.I   = I(:,:,nRGB); opts.beta  = [1,1,1];
    if strcmpi(ImagName,'peppers.png')
        opts.arrEnha = 'edge'; opts.EnCpar = 1e-8; %%% pepper+blur
        opts.tau=0.25; opts.krho=2; opts.ksig=1;
    elseif strcmpi(ImagName,'boatpart.png')
        opts.arrEnha = 'edge'; opts.EnCpar = 1e-8; %%% boat+blur
        opts.tau=0.25; opts.krho=2; opts.ksig=1; 
    elseif strcmpi(ImagName,'fingerprintpart.png')
        opts.arrEnha = 'cohere'; opts.EnCpar = 1e-9; opts.Enalp =1e-3; %% finger+blur
        opts.tau=0.5; opts.krho=10; opts.ksig=1; 
    elseif strcmpi(ImagName,'housergb.png')
        opts.arrEnha = 'edge'; opts.EnCpar = 1e-9; %%% house+blur
        opts.tau=0.25; opts.krho=3; opts.ksig=2; 
    elseif strcmpi(ImagName,'baboonpart.png')
        opts.arrEnha = 'cohere'; opts.EnCpar = 1e-12; opts.Enalp =1e-2; %% Baboon+blur
        opts.tau=0.2; opts.krho=3; opts.ksig=2;
    else
        opts.arrEnha = 'cohere'; opts.EnCpar = 1e-9; opts.Enalp =1e-8; %% 
        opts.tau=5; opts.krho=3; opts.ksig=3;  
    end
    outs = Solver_StruTensorV2(xb(:,:,nRGB),h,ind,opts);
    xres(:,:,nRGB)= outs.x;     
    PSNR(:,nRGB)  = outs.PSNR;     
    SSIM(:,nRGB)  = outs.SSIM; 
end


%% %%%%%%
figure; 
subplot(221); imshow(xb,[],'border','tigh');  title('observed')
subplot(223); imshow(f,[],'border','tigh');  title('filter')
subplot(224); imshow(xres,[],'border','tigh'); title('dejittered')
 
 

 


