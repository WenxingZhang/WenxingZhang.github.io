% function [Wx,Outs] = LBregmanBBNuman(h,W,WT,S,opts)

function [x,PSNR,SSIM,Obj,Time,Error] = L_Bregman_TV(h,x0,opts)

[n1,n2] = size(opts.I);            %%%%%% size of image
mu = opts.mu;  alpha= opts.alpha;  
I    = opts.I;      MaxIt = opts.MaxIt;

%%%%  convolution operator 
siz= size(h);       center = fix(siz/2+1);
P  = zeros(n1,n2);  P(1:siz(1),1:siz(2)) = h;
e  = zeros(n1,n2);  e(1,1) = 1;
D  = dct2(dctshift(P,center))./dct2(e);  
B  = @(x) idct2(D.*dct2(x));       %%%% Blur operator.  B x 
BT=B;




%%% Initinalization

xp   = x0;               %%%% wavelet coefficent  
x   = xp;
yp  = zeros(size(x0));
y   = zeros(size(x0));

% yp  = Ib;
% y   = Ib;
Axp = B(xp);
Ax  = B(x);


Im  = norm(I,'fro')^2;
PSNR = zeros(1,MaxIt);
Obj  = zeros(1,MaxIt);  
SSIM = zeros(1,MaxIt);  
Error= zeros(1,MaxIt); 
Time= zeros(1,MaxIt);
time= cputime;
fprintf('Linear Bregman method is runing .......\n');
for Itr = 1:MaxIt    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Time(Itr)=cputime-time; 
    PSNR(Itr)  = psnr(x,I);     %%% PSNR
    K = [0.05 0.05]; 
    L = 1;   window  = ones(8);    
    [mssim,ssim_map] = ssim_index(x,I, K, window, L);
    SSIM(Itr) = mssim;
%     Obj(Itr)  = norm(x{1}(:),1);   
    if mod(Itr,10)==0   %%%%%% show results
%         figure(2); imshow(Wx,[]);
%         title(sprintf('Wavelets: It:%3d ',Itr),'FontSize',16); drawnow;
        fprintf('Wavelets===Iter:%3d   CPU:%4.3f   SNR: %5.5f\n', ...
            Itr,Time(Itr),PSNR(Itr));
    end 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    
     %%%%% x^{k+1}
    Axpp= Axp;
    Axp = Ax;
    ATy = BT(y);
    Tep = alpha*ATy;
    
    x   = Tep - max(-mu*alpha,min(Tep,mu*alpha));
    Ax  = B(x);
    
    %%%%%  y^{k+1}
    dg  = Axp-Axpp;
    ypp = yp;
    yp  = y;
    dy  = yp-ypp;
    tau = max(1e-3,min((dy(:)'*dg(:))/(dg(:)'*dg(:)),1));
    y   = y + tau*(x0-Ax);
    
    Outs.PSNR = PSNR; Outs.SSIM = SSIM;  
    Outs.Obj = Obj;   Outs.Time = Time; Outs.Error=Error;

end

function [f, g] = fg(y,Ax,x0)
f = y(:)'*(Ax(:)-x0(:));
g = Ax-x0; g=g(:);



  