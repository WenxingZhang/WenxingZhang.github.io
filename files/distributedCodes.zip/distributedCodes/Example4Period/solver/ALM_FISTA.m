function [x,Outs] = ALM_FISTA(h,x0,opts,Method)


beta = opts.beta;       Lip  = opts.Lip;
MaxIt= opts.MaxIt;      nitr = opts.nitr;  I = opts.I;  
% InnerTol = 2.55*1e-3;
% InnerTol = 1.55*1e-3; 
% InnerTol = 3.99*1e-4;

[n1,n2,n3] = size(x0); 
%%%%%%%%%%%  Periodic  boundary condtion (can be used for RGB image)
siz = size(h);    center = fix(siz/2+1);
P  = zeros(n1,n2,n3); for i =1:n3; P(1:siz(1),1:siz(2),i) = h; end
D  = fft2(circshift(P,1-center));
B  = @(x) real(ifft2(D.*fft2(x)));       %%%% Blur operator.  B x 
BT = @(x) real(ifft2(conj(D).*fft2(x))); %%%% Transpose of blur operator.
Px = @(x) [x(2:n1,:,:)-x(1:n1-1,:,:); x(1,:,:)-x(n1,:,:)]; %%% partial x 
Py = @(x) [x(:,2:n2,:)-x(:,1:n2-1,:), x(:,1,:)-x(:,n2,:)]; %%% partial y


x    = x0+0*randn(n1,n2);    %%% observed image  
lbd  = zeros(n1,n2); 
PSNR = zeros(1,MaxIt);  
Obj  = zeros(1,MaxIt);  
SSIM = zeros(1,MaxIt);  
Error= zeros(1,MaxIt);  
Time = zeros(1,MaxIt);
fprintf('ALM is runing .......\n'); 
fprintf('beta=%3.2f;',beta);
StopRule= opts.StopRule; k=1;
%%%%%%%% start the iteration
time = cputime; 
for Itr = 1:MaxIt    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Time(Itr) = cputime-time;     
    PSNR(Itr) = psnr(x,I);     %%% PSNR and SSIM
    K = [0.05,0.05]; L = 1;   window  = ones(8);    
    [mssim,~] = ssim_index(x,I, K, window, L);
    SSIM(Itr) = mssim;
    sk1 = Px(x); sk2 = Py(x); 
    Obj(Itr)=sum(sum(sqrt(sk1.^2+sk2.^2)));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    %%%%% x^{k+1}
    tep = x0 + lbd/beta;
    if strcmpi(Method,'fista')
        xn = FISTA(B,BT,tep,1/beta,Lip,x,nitr);
    elseif strcmpi(Method,'ista')
        xn =  ISTA(B,BT,tep,1/beta,Lip,x,nitr);  
    else
        fprintf('Wrong inner iteration! (either fista or ista)\n');
    end

%     Error(Itr)= norm(x-xn,'fro')^2/norm(x,'fro')^2;
    Error(Itr)= norm(x-I,'fro')^2/norm(I,'fro')^2;
    %%%%%%%  update lambd 
    x   = xn;
    Ax  = B(x);
    lbd = lbd - beta*(Ax-x0);


    
%     if mod(Itr,50)==0    
        
    if Error(Itr)<StopRule(k) && Itr>20  
        figure(2); imshow(x,[]);  
        title(sprintf('It:%3d ',Itr),'FontSize',16); drawnow;
        fprintf('ALM+FISTA==Itr:%3d;CPU:%4.1f;PSNR:%5.2f;SSIM:%5.4f;Err:%4.2e\n', ...
            Itr,Time(Itr),PSNR(Itr),SSIM(Itr),StopRule(k));
        k=k+1;
    end
         
                
end
Outs.PSNR = PSNR;
Outs.SSIM = SSIM; 
Outs.Obj = Obj;
Outs.Time = Time;
Outs.Error=Error;




%%%% FISTA for inner iteration
function x = FISTA(B,BT,b,tau,L,x,nitr)
%%% min tau*|\nabla x|+0.5|Ax-b|
%%% L-- lipstiz constant
%%% x -- initial point
t = 1;
y = x;
yn= x;
for itr = 1:nitr
    Temp = BT(B(y)-b);
    tep= y - Temp/L;
    xn = tvdenoising(tep,tau/L,nitr);
    tn = (1 + sqrt(1+4*t*t))/2;
    yn = xn + ((t-1)/tn)*(xn-x);
    y  = yn;
    x  = xn;
    t  = tn;
end

%%%%% ISTA for inner iteration
% function x = ISTA(B,BT,b,tau,L,x,nitr)
% 
% for itr = 1:nitr
%     Temp = x - BT(B(x)-b)/L;
%     x = Temp - max(-tau/L,min(Temp,tau/L));     
% end




   
    
   