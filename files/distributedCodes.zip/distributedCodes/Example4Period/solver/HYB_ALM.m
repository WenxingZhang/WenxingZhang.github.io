function [x,Outs] = HYB_ALM(h,x0,opts)

%%%%%%%%  Image deblur with total variation     %%%
%%%    min \|\nabla x\|_1     s.t. Bx = x0      %%%
%%%     B - blurry operator                     %%%
%%%     x - ideal image                         %%% 
%%%     x0- observed image                      %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% parameters
r = opts.r;  s = opts.s;          
I = opts.I;  MaxIt = opts.MaxIt;  nitr = opts.nitr; 

if ~isfield(opts,'arr'); opts.arr = 'dynamic'; end 

[n1,n2,n3] = size(x0); 
%%%%%%%%%%%  Periodic  boundary condtion (can be used for RGB image)
siz= size(h);    center = fix(siz/2+1);
P  = zeros(n1,n2,n3); for i =1:n3; P(1:siz(1),1:siz(2),i) = h; end
D  = fft2(circshift(P,1-center));
B  = @(x) real(ifft2(D.*fft2(x)));       %%%% Blur operator.  B x 
BT = @(x) real(ifft2(conj(D).*fft2(x))); %%%% Transpose of blur operator.
Px = @(x) [x(2:n1,:,:)-x(1:n1-1,:,:); x(1,:,:)-x(n1,:,:)]; %%% partial x 
Py = @(x) [x(:,2:n2,:)-x(:,1:n2-1,:), x(:,1,:)-x(:,n2,:)]; %%% partial y

%%%%%%%%% Initinalization
x    = x0+0*randn(n1,n2);    %%% observed image  
lbd  = zeros(n1,n2); 
MatH0= s+(abs(D).^2)/r;  %%% H0 matrix under DCT transform
PSNR = zeros(1,MaxIt);  
Obj  = zeros(1,MaxIt);  
SSIM = zeros(1,MaxIt);  
Error= zeros(1,MaxIt);  
Time = zeros(1,MaxIt);

fprintf('\nHeYuan-Balanced ALM without correction is runing .......\n'); 
fprintf('r=%3.2f;s=%3.2f;',r,s);


%%%%%%%% start the iteration
StopRule= opts.StopRule; k=1;

time = cputime; 

for Itr = 1:MaxIt    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Time(Itr) = cputime-time;     
    PSNR(Itr) = psnr(x,I);     %%% PSNR
    K = [0.05, 0.05]; L = 1;   window = ones(8);    
    [mssim,~] = ssim_index(x,I, K, window, L);
    SSIM(Itr) = mssim;
    sk1 = Px(x); sk2 = Py(x); 
    Obj(Itr)=sum(sum(sqrt(sk1.^2+sk2.^2)));
        
    %%% x
    qk   = x + BT(lbd)/r;
    xn   = tvdenoising(qk,1/r,nitr);
    
    %%% lambda 
    Ax   = B(x);
    Axn  = B(xn);
%     DCTx = fft2(x); 
%     DCTxn= fft2(xn); 
    tep  = x0 - (2*Axn-Ax); 
    lbdn = lbd + real(ifft2(fft2(tep)./MatH0));  

%         Error(Itr)= norm([Mu_x,Mu_lbd],'fro')^2;
%     Error(Itr)= norm(x-xn,'fro')^2/norm(x,'fro')^2;
    Error(Itr)= norm(x-I,'fro')^2/norm(I,'fro')^2;
    
    x = xn; lbd = lbdn; 
    
        
%     if mod(Itr,50)==0    
    if Error(Itr)<StopRule(k) && Itr>5  
        figure(2); imshow(x,[]);  
        title(sprintf('It:%3d ',Itr),'FontSize',16); drawnow;
        fprintf('HeYuan-BalanceALM==Itr:%3d;CPU:%3.1f;PSNR:%5.2f;SSIM:%5.4f;Err:%4.2e\n', ...
            Itr,Time(Itr),PSNR(Itr),SSIM(Itr),StopRule(k));
        k=k+1;
    end 

end

Outs.PSNR = PSNR;
Outs.SSIM = SSIM;
Outs.Obj  = Obj;
Outs.Time = Time;
Outs.Error= Error;

end

 
