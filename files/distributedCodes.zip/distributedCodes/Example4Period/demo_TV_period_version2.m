%%%%%%%%%%% Image deblur with total variation   %%%
%%%    min \|\nabla x\|_1     s.t. Bx = x0      %%%
%%%     B - blurry operator                     %%%
%%%     x - ideal image                         %%% 
%%%     x0- observed image                      %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Authored by: Wenxing Zhang, UESTC, Dec, 2023
%%% Y.M. Li, H.W. Xu, W.X. Zhang, A balanced augmented Lagrangian method
%%% with correction for linearly constrained optimization, 
%%% J Sci Comput, 104(20), 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc; clear; close all;
root = fileparts(which(mfilename)); 
cd(root);
addpath(genpath(root));
scrsz  = get(groot,'ScreenSize');  %%% figure setting
FigSize= scrsz(4)*[0.5 0.2 0.55 0.4];
rand('seed',0); rand('state',0);

%%%%%%%%% test image   %%%%%%%%%%%%%%%%%%%
I = double(imread('montage.png'));  I = I(129:end,129:end); I = I(1:2:end,1:2:end); %%64x64
% I = double(imread('circles.tif'));  I = I(1:2:end,1:2:end); %%128x128
% I = double(imread('pepper.png'));   %%256x256
% I = double(imread('boat.png'));    %%512x512
% I = double(imread('man.tiff'));    %%1024x1024

%%%%%%%% blur and observed image
h  = fspecial('disk',21);  
h  = fspecial('Gaussian',19,7);
h  = fspecial('average',35);

x0 = imfilter(I,h,'circular');

opts.I = I;  
opts.StopRule=[10e-3,8e-3,6e-3,4e-3,2e-3,1e-3]; %%% stopping rule
opts.MaxIt = 20; 

%% HeYuan's Balanced-ALM 
opts.r=0.2; opts.s=0.2;  opts.nitr=45;    %%%% plot Table and figure
[x6,Outs6] = HYB_ALM(h,x0,opts); 
%% ours: Balanced ALM with correction
opts.r=0.1; opts.s=0.1; opts.gamma=1.5; opts.nitr=45; %%%%% plot Table
NBand = [-0.85 0.15];
for i = 1:length(NBand)
    opts.alpha = NBand(i);  
    [x,Outs] = Ours(h,x0,opts);
    mat{1}(i,:) = Outs.Obj;   %%%Obj   data
    mat{2}(i,:) = Outs.PSNR;  %%%PSNR  data
    mat{3}(i,:) = Outs.SSIM;  %%%SSIM  data  
    mat{4}(i,:) = Outs.Error; %%%Error data  
    Time(i,:)   = Outs.Time;  %%%CPU   data    
end

%%  
stry   = {'Obj','PSNR','SSIM','Error'};  %%% data
Mark   = {'-','o','s','d','^',':'};      %%%% method
RGB=[0,0,0;1 0 1;0 0 1;1 0.4 0;0 1 1;1 0 0;0 1 0;...
0 0.4470 0.7410; 0.8500 0.3250 0.0980;0.9290 0.6940 0.1250;...
0.4940 0.1840 0.5560;0.4660 0.6740 0.1880;0.3010 0.7450 0.9330;...
0.6350 0.0780 0.1840]'; %%% choices of colors
  
c = 1:opts.MaxIt;  
for ndata = 1:length(mat)  %%% PSNR, SSIM, Error w.r.t CPU time
    fig(ndata) = figure('Position',FigSize); 
    C =[Time(1,c),fliplr(Time(2,c))];
    M =[mat{ndata}(1,c),fliplr(mat{ndata}(2,c))];
    patch(C,M,'g','FaceAlpha',0.7,'EdgeColor','g','linewidth',2); hold on
    for i=6  %%%% test methods (if many methods)
        semilogy(eval(['Outs',num2str(i),'.Time(c)']),...
           eval(['Outs',num2str(i),'.',stry{ndata},'(c)']),...
           'linewidth',2,'color',RGB(:,i)); hold on
    end 
    set(gca,'fontSize',15,'fontweight','bold');
    xlabel('CPU  time (s)','fontsize',22,'fontweight','bold');
    ylabel(stry{ndata},'fontsize',22,'fontweight','bold'); grid minor; box on
end   
 

%% 
stry   = {'Obj','PSNR','SSIM','Error'};  %%% data
Mark   = {' ','o','s','d','^',' '};      %%%% method
LinSty = {'-','-','-','-','-','-'};      %%%% method
nMethod= length(Mark);
RGB=[0,0,0;1 0 1;0 0 1;1 0.4 0;0 1 1;1 0 0;0 1 0;...
0 0.4470 0.7410; 0.8500 0.3250 0.0980;0.9290 0.6940 0.1250;...
0.4940 0.1840 0.5560;0.4660 0.6740 0.1880;0.3010 0.7450 0.9330;...
0.6350 0.0780 0.1840]';  %%% choices of colors
Nsp = length(NBand);
c = 1:opts.MaxIt;  
a = 1:5:opts.MaxIt;  
for ndata = 1:length(mat) %%% Iteration No.: obj, psnr, ssim, error
    fig(ndata) = figure('Position',FigSize); %% figure handles
    for i=1:Nsp-1
        C = [c+1,fliplr(c+1)];
        M = [mat{ndata}(i,:),fliplr(mat{ndata}(i+1,:))];
        fill(C,M,'g','FaceAlpha',1,'EdgeColor','g','linewidth',2); hold on
    end       
    for i=6  %%%% test methods: only line
        semilogy(c,eval(['Outs',num2str(i),'.',stry{ndata},'(c)']),...
            LinSty{i},'linewidth',2,'color',RGB(:,i)); hold on
    end  
    set(gca,'fontSize',15,'fontweight','bold'); grid on;
    xlabel('Iteration  No.','fontsize',22,'fontweight','bold');
    ylabel(stry{ndata},'fontsize',22,'fontweight','bold'); grid minor; box on
end 
   