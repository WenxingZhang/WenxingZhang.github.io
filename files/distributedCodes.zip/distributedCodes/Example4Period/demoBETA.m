%%%%%%%%%%% Image deblur with total variation   %%%
%%%    min \|\nabla x\|_1     s.t. Bx = x0      %%%
%%%     B - blurry operator                     %%%
%%%     x - ideal image                         %%% 
%%%     x0- observed image                      %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% This codes is just to check the performance of parameter beta
clc; clear; close all;
addpath ././ Images  utils  solver 
rand('seed',0); rand('state',0);

%%%%%%%%% test image   %%%%%%%%%%%%%%%%%%%
% I = double(imread('montage.png'));  I = I(129:end,129:end); I = I(1:2:end,1:2:end); %%64x64
% I = double(imread('circles.tif'));  I = I(1:2:end,1:2:end); %%128x128
% % I = double(imread('pepper.png'));   %%256x256
% % I = double(imread('boat.png'));    %%512x512
% % I = double(imread('man.tiff'));    %%1024x1024
% 
% %%%%%%%%%%%% blur and observed image
% h  = fspecial('disk',21);  
% h  = fspecial('Gaussian',19,7);
% h  = fspecial('average',35);
% x0 = imfilter(I,h,'circular');
% 
% opts.I = I;  
% opts.StopRule=[9e-3,8e-3,7e-3,6e-3,5e-3,4e-3,3e-3,0]; %%% stopping rule
% opts.MaxIt = 100; 

%% HeYuan's Balanced-ALM 
% opts.r=0.2; opts.s=0.2;  opts.nitr=45;    %%%% plot Table and figure
% [x6,Outs6] = HYB_ALM(h,x0,opts);

%% ours: Balanced ALM with correction
% opts.r=0.2; opts.s=0.2; opts.gamma=1.5; opts.nitr=45; %%%%% plot Table
% % NBand = [-0.85 0.15];
% NBand = [0.15];
% for i = 1:length(NBand)
%     opts.alpha = NBand(i);  
%     [x,Outs9] = Ours(h,x0,opts);
%     mat{1}(i,:) = Outs9.Obj;   %%%Obj   data
%     mat{2}(i,:) = Outs9.PSNR;  %%%PSNR  data
%     mat{3}(i,:) = Outs9.SSIM;  %%%SSIM  data  
%     mat{4}(i,:) = Outs9.Error; %%%Error data  
%     Time(i,:)   = Outs9.Time;  %%%CPU   data    
% end

% 
% figure;
% a=1:opts.MaxIt; 
% subplot(221); plot(a, Outs6.PSNR,'-dr',a, Outs8.PSNR,'-og',a, Outs9.PSNR,'-sb')
% subplot(222); plot(a, Outs6.Error,'-dr',a, Outs8.Error,'-og',a, Outs9.Error,'-sb')
% subplot(223); plot(Outs6.Time, Outs6.PSNR,'-dr',Outs8.Time, Outs8.PSNR,'-og',Outs9.Time, Outs9.PSNR,'-sb')
% subplot(224); plot(Outs6.Time, Outs6.Error,'-dr',Outs8.Time, Outs8.Error,'-og',Outs9.Time, Outs9.Error,'-sb')


%% %%%%%%%%%%%%%% Evolution of beta w.r.t. iter for ours method
clc
clear 
I = double(imread('montage.png'));  I = I(129:end,129:end); I = I(1:2:end,1:2:end); %%64x64
TestImage{1}=I; 
I = double(imread('circles.tif'));  I = I(1:2:end,1:2:end); %%128x128
TestImage{2}=I; 
% I = double(imread('pepper.png'));   %%256x256
% TestImage{3}=I; 
% I = double(imread('boat.png'));    %%512x512
% TestImage{4}=I; 
% I = double(imread('man.tiff'));    %%1024x1024
% TestImage{5}=I; 

opts.MaxIt = 110; opts.StopRule=[5e-3,4e-3,3e-3,0];  %%% stopping rule
opts.r=0.2; opts.s=0.2; opts.gamma=0.5; opts.nitr=45; %%% plot Table
opts.r=0.5; opts.s=0.5; opts.gamma=0.5; opts.nitr=45; %%% plot Table
NBand = [-0.3  0.15];

for Nim=1:length(TestImage)
    I  = TestImage{Nim}; opts.I = I;  
    h  = fspecial('Gaussian',19,7); 
    x0 = imfilter(I,h,'circular'); 
    
    for i = 1:length(NBand)
        opts.alpha = NBand(i);  
        [x,Outs]  = Ours(h,x0,opts);
        mat{Nim}(i,:) = Outs.Beta; %%%beta parameter
    end
end
 
%%
load Betagamma05
% load Betagamma10
% load Betagamma15
close all  %%%% figures in paper: iter
scrsz  = get(groot,'ScreenSize');  
SizeFig= [scrsz(4)/2 scrsz(4)/5 scrsz(4)*0.55 scrsz(4)*0.4]; 
RGB=[0 1 1;1 0 0;0 1 0;1 0 1;0 0 1;1 0.4 0;0,0,0;...
0 0.4470 0.7410; 0.8500 0.3250 0.0980;0.9290 0.6940 0.1250;...
0.4940 0.1840 0.5560;0.4660 0.6740 0.1880;0.3010 0.7450 0.9330;...
0.6350 0.0780 0.1840]; %%% options of colors
Nsp = length(NBand);
c = 1:opts.MaxIt;  
fig= figure('Position',SizeFig); 
for Nim = 1:length(TestImage) %%% band of beta for each image
    for i=1:Nsp-1
        C = [c,fliplr(c)];
        M = [mat{Nim}(i,:),fliplr(mat{Nim}(i+1,:))];
        fill(C,M,RGB(Nim,:),'FaceAlpha',1-0.45*Nim/5,'EdgeColor','none'); hold on
    end
    set(gca,'fontSize',14,'fontweight','bold'); grid on;
    xlabel('Iteration  No.','fontsize',22,'fontname','Times New Roman','fontweight','bold');
    ylabel('Value  of  \beta_{\itk}','fontsize',22,'fontname','Times New Roman','fontweight','bold'); grid minor; box on
end 
 
text([35],[1.11],'{\itr}=0.5, {\its}=0.5',...
    'fontsize',18,'color','k','fontweight','bold',...
    'fontname','Times New Roman','edgecolor','k','linewidth',1.5);

axis([1,100,0.85,1.18]); 
 