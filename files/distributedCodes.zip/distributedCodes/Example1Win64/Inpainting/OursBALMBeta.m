function [Wx,Outs] = OursBALMBeta(h,W,WT,S,opts)

%%%%% This code solve wavelet based image inpainting

[n1,n2] = size(opts.I); 
r  = opts.r;  s = opts.s;  alpha = opts.alpha;  InnerIt = opts.InnerIt;
Ib = opts.Ib; I = opts.I;  MaxIt = opts.MaxIt;  InnerTol = 1e-6;
if ~isfield(opts,'arr'), opts.arr = 'dynamic'; end

%%% convolution operator 
siz = size(h);        center = fix(siz/2+1);
P   = zeros(n1,n2);   P(1:siz(1),1:siz(2)) = h;
e   = zeros(n1,n2);   e(1,1) = 1;
D   = dct2(dctshift(P,center))./dct2(e);  
B   = @(x) idct2(D.*dct2(x));  
D2  = D.^2;   %% B^TB in cos domain 

%%% convolve + wavelet: A = SBW
% A  = @(x) S.*(B(W(x)));                        
AT = @(x) WT(B(S.*x));

%%% Initinalization  
x    = WT(Ib);      %%% observed image initial point  
lbd  = zeros(n1,n2); 
MDH0 = @(x) LSP(D2,S,r,s,x,n1,n2);
xn   = WT(Ib); % cell array
xnew = WT(Ib); % cell array

PSNR = zeros(1,MaxIt);  
Obj  = zeros(1,MaxIt);  
SSIM = zeros(1,MaxIt);  
Error= zeros(1,MaxIt);  
Time = zeros(1,MaxIt);  
BETA = zeros(1,MaxIt);  


fprintf('\n ours B-ALM+ with correction is runing .......\n'); 
fprintf('r=%3.2f;s=%3.2f;alpha=%2.2f;gamma=%2.2f;InnerIt=%2d\n\n',r,s,alpha,opts.gamma,InnerIt);

StopRule= opts.StopRule; k=1;
%%%%%%%% start the iteration
time = cputime;  
for Itr = 1:MaxIt    

    Wx  = W(x);  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Time(Itr)=cputime-time;    
    PSNR(Itr)  = psnr(Wx,I);     %%% PSNR and SSIM
    K = [0.05 0.05];   L = 1;   window  = ones(8);    
    [mssim,ssim_map] = ssim_index(Wx,I, K, window, L);
    SSIM(Itr) = mssim;
    Obj(Itr)  = norm(x{1}(:),1);
    Error(Itr)= norm(Wx-I,'fro')^2/norm(I,'fro')^2;
   
    if Error(Itr)<StopRule(k) && Itr>3
%         figure(2); imshow(Wx,[]);  
%         title(sprintf('It:%3d ',Itr),'FontSize',16); drawnow;
        fprintf('Ours-BALM==Itr:%3d;CPU:%4.1f;PSNR:%5.2f;SSIM:%5.4f;Err:%4.2e\n', ...
            Itr,Time(Itr),PSNR(Itr),SSIM(Itr),StopRule(k));
        k=k+1;
    end
    
    
    %%%%%%%%%% prediction phase
    %%% lambda 
    Ax      = S.*B(Wx); 
    [tep,~] = pcg(MDH0,Ib(:)-Ax(:),InnerTol,InnerIt); %%%%% inv(H0)*(b-Ax)
    lbdn    = lbd + reshape(tep,n1,n2);  
        
    %%% x
    tep   = AT(lbdn+alpha*(lbdn-lbd));
    qk    = x{1} + tep{1}/r; 
    xn{1} = qk - max(-1/r,min(qk,1/r)); 
    Wxn   = W(xn);
    Axn   = S.*B(Wxn); 
        
    %%%%%%%%%%%% correction phase
    dx    = x; dx{1} = x{1} - xn{1};  Adx = Ax-Axn;
    dlbd  = lbd-lbdn;  ATdlbd = AT(dlbd);
    Mu_x  = dx{1}-(alpha/r)*ATdlbd{1}; 
    [invH0Adx,~]= pcg(MDH0,Adx(:),InnerTol,InnerIt);%%% inv(H0)*A(x-xn)
    Mu_lbd = dlbd - reshape(invH0Adx,n1,n2);
    
    %%% stepsize beta
    if strcmpi(opts.arr,'dynamic');
        beta_num = r*norm(dx{1},'fro')^2-(1+alpha)*(dlbd(:))'*Adx(:)+ ...
            norm(ATdlbd{1},'fro')^2/r+s*norm(dlbd,'fro')^2; 
        beta_dom = 2*beta_num - r*norm(dx{1},'fro')^2 ...
            + (Adx(:))'*invH0Adx(:) -(1-alpha^2)*norm(ATdlbd{1},'fro')^2/r-s*norm(dlbd,'fro')^2;
        beta =beta_num/beta_dom;
    end
    
    xnew{1} = x{1} -  opts.gamma*beta*Mu_x;
    lbdnew  = lbd  -  opts.gamma*beta*Mu_lbd;

    BETA(Itr) = beta;  

    x{1} = xnew{1};   
    lbd = lbdnew; 
    
end
 
Outs.PSNR = PSNR;
Outs.SSIM = SSIM; 
Outs.Obj  = Obj;
Outs.Time = Time;
Outs.Error= Error;
Outs.BETA= BETA;

end


function H0x = LSP(D2,S,r,s,x,n1,n2)
xx  = reshape(x,n1,n2);
BBSx= idct2(D2.*dct2(S.*xx));  
H0x = S.*BBSx/r + s*xx;
H0x = H0x(:);
end



