function [Wx,Outs] = HY_BALM(h,W,WT,S,opts)

%%%%% This code solve the wavelet based image inpainting
[n1,n2] = size(opts.I); 
r  = opts.r;  s = opts.s;  InnerIt = opts.InnerIt;
Ib = opts.Ib; I = opts.I;  MaxIt = opts.MaxIt;  InnerTol = 1e-6;

%%% convolution operator 
siz = size(h);        center = fix(siz/2+1);
P   = zeros(n1,n2);   P(1:siz(1),1:siz(2)) = h;
e   = zeros(n1,n2);   e(1,1) = 1;
D   = dct2(dctshift(P,center))./dct2(e);  
B   = @(x) idct2(D.*dct2(x));  
D2  = D.^2;   %% B^TB in DCT domain 

%%% convolve + wavelet: A = SBW
A  = @(x) S.*(B(W(x)));                        
AT = @(x) WT(B(S.*x));

%%% Initinalization  
x    = WT(Ib);         %%% observed image initial point  
lbd  = zeros(n1,n2); 
MDH0 = @(x) LSP(D2,S,r,s,x,n1,n2);
xn   = WT(Ib); % cell array
Wx   = W(x); 

PSNR = zeros(1,MaxIt);  
Obj  = zeros(1,MaxIt);  
SSIM = zeros(1,MaxIt);  
Error= zeros(1,MaxIt);  
Time = zeros(1,MaxIt);  

fprintf('\nHeYuan-BALM is runing with:'); 
fprintf('r=%3.2f;s=%3.2f;InnerIt=%2d\n',r,s,InnerIt);

StopRule= opts.StopRule; k=1;
%%%%%%%% start the iteration
time = cputime;  
for Itr = 1:MaxIt    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Time(Itr) = cputime-time;    
    PSNR(Itr) = psnr(Wx,I);     %%% PSNR and SSIM
    K = [0.05 0.05];  L = 1;   window  = ones(8);    
    [mssim,ssim_map] = ssim_index(Wx,I, K, window, L);
    SSIM(Itr) = mssim;
    Obj(Itr)  = norm(x{1}(:),1);
    Error(Itr)= norm(Wx-I,'fro')^2/norm(I,'fro')^2;
    
%     if mod(Itr,20)==0    
%         figure(2); imshow(Wx,[]);  
%         title(sprintf('Wavelets: It:%3d ',Itr),'FontSize',16); drawnow;%
%         fprintf('HeYuanB-ALM==Itr:%3d;CPU:%4.1f;PSNR:%4.2f;SSIM:%4.4f;Error:%3.2e\n', ...
%             Itr,Time(Itr),PSNR(Itr),SSIM(Itr),Error(Itr));
%     end
    
    if Error(Itr)<StopRule(k) && Itr>3
%         figure(2); imshow(Wx,[]);  
%         title(sprintf('It:%3d ',Itr),'FontSize',16); drawnow;
        fprintf('HY-BALM==Itr:%3d;CPU:%4.1f;PSNR:%5.2f;SSIM:%5.4f;Err:%4.2e\n', ...
            Itr,Time(Itr),PSNR(Itr),SSIM(Itr),StopRule(k));
        k=k+1;
    end   
    %%% x
    tep   = AT(lbd);
    qk    = x{1} + tep{1}/r; 
    xn{1} = qk - max(-1/r,min(qk,1/r)); 
    
    
    %%% lambda 
    Wxn  = W(xn);  
    ExtAx   = S.*B(2*Wxn-Wx); 
    [tep,~] = pcg(MDH0,Ib(:)-ExtAx(:),InnerTol,InnerIt); %%%%% inv(H0)*(b-A(2xn-x))
    lbdn    = lbd + reshape(tep,n1,n2);  
    
    x{1} = xn{1}; Wx = Wxn;
    lbd  = lbdn; 
    
end
 
Outs.PSNR = PSNR;
Outs.SSIM = SSIM; 
Outs.Obj  = Obj;
Outs.Time = Time;
Outs.Error= Error;

end


function H0x = LSP(D2,S,r,s,x,n1,n2)
xx  = reshape(x,n1,n2);
BBSx= idct2(D2.*dct2(S.*xx));  
H0x = S.*BBSx/r + s*xx;
H0x = H0x(:);
end



