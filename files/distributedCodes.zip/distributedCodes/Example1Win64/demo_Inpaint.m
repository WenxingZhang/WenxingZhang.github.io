%%%%%%%%%%%%%%% Image inpainting with wavelets. %%%
%%%    min \|x\|_1     s.t. SBWx = b            %%%
%%%     B - blurry operator                     %%%
%%%     W - wavelets dictionary                 %%%
%%%     S - downsampling matrix for zooming     %%%
%%%       - or mask for inpainting              %%%
%%%     x - sparse representation under W       %%% 
%%%     b - observed image                      %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Authored by: Wenxing Zhang, UESTC, Dec, 2023
%%% Y.M. Li, H.W. Xu, W.X. Zhang, A balanced augmented Lagrangian method
%%% with correction for linearly constrained optimization, 
%%% J Sci Comput, 104(20), 2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc; clear; close all;
root = fileparts(which(mfilename)); 
cd(root);
addpath(genpath(root));
scrsz  = get(groot,'ScreenSize');  %%% figure setting
FigSize= scrsz(4)*[0.5 0.2 0.55 0.4];
rand('seed',0); randn('state',0);

%%%%%%%%%%%%% Original Image %%%%%%%%%%%%%%%%%%%
I = double(imread('montage.png')); I=I(129:2:end,129:2:end); %%64x64
% I = double(imread('circles.tif')); I = I(1:2:end,1:2:end); %%128x128
% I = double(imread('pepper.png'));     %%256x256
% I = double(imread('boat.png'));       %%512x512
% I = double(imread('man.tiff'));       %%1024x1024
 

%%%%%%%%%%%% Haar wavelet representation
wav= 'db2';    levels = 4;
W = @(x) mirdwt_TI2D(x,wav);       % inverse: ->image
WT= @(x) mrdwt_TI2D(x,wav,levels); % forward: ->coefficient
 
%%%%%%%%%% Mask of inpainting
[n1,n2] = size(I); 
dtx = 64; dty = 64; S1 = rand(dtx,dty)>0.2;   
S2  = ones(n1/dtx,n2/dty);  S = kron(S1,S2); clear S1 S2 

%%% degraded image with reflective boundary 
h  = fspecial('disk',11);   %%%%  PSF
% h  = fspecial('disk',14);   %%%%  PSF
% h  = fspecial('disk',21);   %%%%  PSF
Ib = S.*imfilter(I,h,'symmetric');  

%% %%%%%%% parameters or initial points
opts.I = I; opts.Ib = Ib;  
StRul=(9:-2:1)'*(10.^(-3:-1:-6)); opts.StopRule=StRul(:); clear StRul %% stopping rule

opts.MaxIt=25;
%% %%%%% HeYuan B-ALM 
% opts.r = 0.03; opts.s = 0.03; opts.InnerIt = 35;
% [Wx6,Outs6] = HY_BALM(h,W,WT,S,opts);
% 
% %% %%%%%%% ours B-ALM 
% opts.r = 0.03; opts.s = 0.03; opts.gamma = 1;
% opts.InnerIt = 35; opts.arr='dynamic';  opts.alpha=0.2;
% NBand = [0.5, 1, 1.5];  %%% gamma\in[0,2] 
% for i = 1:length(NBand)
%     opts.gamma = NBand(i);  
%     [Wx,Outs]  = OursBALM(h,W,WT,S,opts);
%     mat{1}(i,:) = Outs.Obj;   %%%Obj   
%     mat{2}(i,:) = Outs.PSNR;  %%%PSNR  
%     mat{3}(i,:) = Outs.SSIM;  %%%SSIM  
%     mat{4}(i,:) = Outs.Error; %%%Error   
%     Time(i,:)   = Outs.Time;  %%%CPU        
% end
% 
% %% %%% plot figures     
% stry   = {'Obj','PSNR','SSIM','Error'};  %%% data
% Mark   = {' ','o','s','d','^',' '};      %%%% method
% LinSty = {'-','-','-','-','-','-'};      %%%% method
% nMethod= length(Mark);
% RGB=[0,0,0;1 0 1;0 0 1;1 0.4 0;0 1 1;1 0 0;0 1 0;...
% 0 0.4470 0.7410; 0.8500 0.3250 0.0980;0.9290 0.6940 0.1250;...
% 0.4940 0.1840 0.5560;0.4660 0.6740 0.1880;0.3010 0.7450 0.9330;...
% 0.6350 0.0780 0.1840]';  %%% choices of colors
% c = 1:opts.MaxIt;   
% for nd = 1:length(mat) %%% Iteration No.: obj, psnr, ssim, error
%     fig(nd) = figure('Position',FigSize); %% figure handles
%     C = [c,fliplr(c)];  %% colorize each strips
%     M = [min(mat{nd},[],1),fliplr(max(mat{nd},[],1))];
%     fill(C,M,'g','FaceAlpha',0.7,'linestyle','none'); hold on 
%     
%     for i=6 %%%% test methods: only line
%         semilogy(c,eval(['Outs',num2str(i),'.',stry{nd},'(c)']),...
%             LinSty{i},'linewidth',2,'color',RGB(:,i)); hold on
%     end  
%     set(gca,'fontSize',15,'fontweight','bold');  
%     xlabel('Iteration  No.','fontsize',22,'fontweight','bold');
%     ylabel(stry{nd},'fontsize',22,'fontweight','bold'); grid minor; box on
% end
%  
% for nd = 1:length(mat)  %%% PSNR, SSIM, Error w.r.t CPU time
%     fig(nd+length(mat)) = figure('Position',FigSize); 
%     C =[Time(1,c),fliplr(Time(2,c))];
%     M =[min(mat{nd},[],1),fliplr(max(mat{nd},[],1))];
%     patch(C,M,'g','FaceAlpha',0.7,'EdgeColor','none'); hold on
%     for i=6  %%%% test methods (if many methods)
%         semilogy(eval(['Outs',num2str(i),'.Time(c)']),...
%             eval(['Outs',num2str(i),'.',stry{nd},'(c)']),...
%            'linewidth',2,'color',RGB(:,i)); hold on
%     end 
%     set(gca,'fontSize',15,'fontweight','bold');
%     xlabel('CPU  time (s)','fontsize',22,'fontweight','bold');
%     ylabel(stry{nd},'fontsize',22,'fontweight','bold'); grid minor; box on
% end   
 
%% performances of parameters: e.g.,various alpha, gamma for B-ALM
% opts.MaxIt = 50; opts.InnerIt = 35;
% opts.r = 0.5; opts.s = 0.5; opts.gamma = 1.2; opts.alpha=1; 
% Nsp = 5; NBand = linspace(0.2,1.5,Nsp); %%%% various gamma  
% for i = 1:Nsp
%     opts.gamma = NBand(i);  %%%%% variant gamma
%     [Wx,Outs] = OursBALM(h,W,WT,S,opts);
%     mat{1}(i,:) = Outs.Obj;   %%%Obj   data
%     mat{2}(i,:) = Outs.Error; %%%Error data
%     mat{3}(i,:) = Outs.PSNR;  %%%PSNR  data
%     mat{4}(i,:) = Outs.SSIM;  %%%SSIM  data    
% end 
% 
% %% %%%%%%% plot colorful strips 
% stry = {'Obj','Error','PSNR','SSIM'};
% Cpt=[linspace(0,1,Nsp-1); sin(linspace(0,pi,Nsp-1)); zeros(1,Nsp-1)];%colorize strips
% c=1:1:opts.MaxIt;  
% for nd=1:length(mat) %%% number of data
%     fig(nd) = figure('Position',FigSize);  %%% figure handles 
%     for i=1:Nsp-1  %% colorize each strips
%         C = [c,fliplr(c)]; M = [mat{nd}(i,:),fliplr(mat{nd}(i+1,:))];
%         fill(C,M,Cpt(:,i)','FaceAlpha',1,'linestyle','none'); hold on
%     end 
%     set(gca,'fontSize',15,'fontweight','bold');
%     xlabel('Iteration  No.','fontsize',22,'fontweight','bold');
%     ylabel(stry{nd},'fontsize',22,'fontweight','bold'); grid on;
% %     print(fig(nd), '-dpng', ['alphafig',num2str(nd)]); %%Parallel system
% end

 
  

%%%%%cross validation: (r,s)-map for balanced ALM
opts.MaxIt = 2; opts.InnerIt = 35;
opts.r = 1; opts.s = 1; opts.gamma = 1.; opts.alpha = 1; 
a = 2.^linspace(-9,1,5);   
b = 2.^linspace(-9,1,5); 
for i = 1:length(a)
    opts.r = a(i);
    for j=1:length(b)
        opts.s = b(j);
        [Wx,Outs] = OursBALM(h,W,WT,S,opts);
        matPSNR(i,j) = Outs.PSNR(end);
        matSSIM(i,j) = Outs.SSIM(end);
        matObj(i,j)  = Outs.Obj(end);
        matError(i,j)= Outs.Error(end);
    end
end

stry  = {'Obj','Error','PSNR','SSIM'};
for nd=1:4
    f(nd)=figure('Position',FigSize);
    imagesc(flipud(eval(['mat',stry{nd}]))); colormap jet; colorbar
    set(gca,'xscale','line','yscale','line',...
        'xtick',4:6:length(b),...,
        'xticklabel',{'2^{-8}','2^{-6}','2^{-4}','2^{-2}','2^{0}'},...
        'ytick',4:6:length(a),...,
        'yticklabel',{'2^{0}','2^{-2}','2^{-4}','2^{-6}','2^{-8}'},...
        'fontsize',14,'fontweight','bold');
    set(gca,'fontsize',15,'fontweight','bold'); 
    xlabel('stepsize {\it s}','fontsize',20,'fontweight','bold');
    ylabel('stepsize {\it r}','fontsize',20,'fontweight','bold'); 
    title([stry{nd},'   Map'],'fontsize',20,'fontweight','bold'); 
%     print(f(nd), '-dpng', ['rsfig',stry{nd}]);
end  

%  CoL=[linspace(0,1,5);sin(linspace(0,pi,5));zeros(1,5)];%blocky legends 
