function Ax = DS(W,B,x,ssp)
%%% A = SB
%%%   S ---- downsampling matrix 
%%%   B ---- blur
%%%   x --- coefficient of image under wavelet

Bx = B(W(x)); 
Ax = Bx(1:ssp:end,1:ssp:end);
    