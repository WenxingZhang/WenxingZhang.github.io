% function p = psnr(x,y,vmax)
% 
% if nargin<3
%     m1 = max( abs(x(:)) );
%     m2 = max( abs(y(:)) );
%     vmax = m2;
% %     vmax = max(m1,m2);
% end
% 
% d = mean( (x(:)-y(:)).^2 );
% 
% p = 10*log10( vmax^2/d );



function [SNR,MSE]=psnr(u0,u)

A=max(max(u0(:)),max(u(:)));
dif=u0(:)-u(:);
MSE=mean(dif.^2);
SNR=10*log10(A*A/MSE);
