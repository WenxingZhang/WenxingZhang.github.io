function ATx = DST(WT,B,sx,ssp)

%%% A = SB
%%%   S ---- downsampling matrix 
%%%   B ---- blur
%%%   x --- low resolution image
[n1,n2]=size(sx);
x = zeros(n1*ssp,n2*ssp);
x(1:ssp:n1*ssp,1:ssp:n2*ssp) = sx;
Bx  = B(x); 
ATx = WT(Bx);
    