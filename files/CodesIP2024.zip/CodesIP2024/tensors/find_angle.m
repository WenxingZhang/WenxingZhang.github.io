function phi=find_angle(vec)
%   this function computes the angle between the vector vec 
%   and the Ox-axis
%   INPUT:
%   vec: n*m vectors assembled as a matrix of size n x m x 2,
%
%   OUTPUT:
%   phi: an n*m matrix containing the angle for each one of 
%   the n*m vectors.

    phi=angle(complex(vec(:,:,1),vec(:,:,2)));
     
end