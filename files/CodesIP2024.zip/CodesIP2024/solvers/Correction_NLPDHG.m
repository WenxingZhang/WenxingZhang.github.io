function outs = Correction_NLPDHG(x0,opts)

%%% Nonlinear PDHG method for solving nonlinear invere problem.
%%% min tau_1\phi_1(Bx) + tau_2\phi_2(y) + \psi(A(y)*x-x0)
%%% tau_1 --- trade-off for x, \phi_1-- prior for x, e.g., t^TDt, or TV 
%%% tau_2 --- trade-off for y, \phi_2-- prior for y, e.g., |.|_2^2
%%%                            \psi  -- fidelity, e.g., |.|_2^2 or |.|_1
%%%Inputs:
%%% x0  --- blurry image
%%% opts.tau  --- trade-offs of model
%%% opts.r,opts.s- step size for PDHG
%%% opts.ksig --- local scale of structure tensor J_rho(\nabla u_\sigma^0)
%%% opts.krho --- average scale of structure tensor J_rho(\nabla u_\sigma^0)
%%% opts.arrEnha---'edge' for edge-enhancing; 'cohere' for coherence-enhancing 
%%% opts.reg1 ---'tv' or 'tensor'
%%% opts.FdT  ---'l1' for L1-norm; 'l2' for L2^2-norm
%%% opts.y    --- initial point y=[sigma1;sigma2;rho]

[n1,n2,n3] = size(x0);
tau1 = opts.tau(1); tau2 = opts.tau(2);
r    = opts.r;
s    = opts.s;
MaxIt= opts.MaxIt;

%%%%%%%%%%% Periodic boundary condtion %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Px  = @(x) [x(2:n1,:,:)-x(1:n1-1,:,:); x(1,:,:)-x(n1,:,:)]; %%\nabla_1 x 
Py  = @(x) [x(:,2:n2,:)-x(:,1:n2-1,:), x(:,1,:)-x(:,n2,:)]; %%\nabla_2 y
PTx = @(x) [x(n1,:,:)-x(1,:,:); x(1:n1-1,:,:)-x(2:n1,:,:)]; %%\nabla_1^T x 
PTy = @(x) [x(:,n2,:)-x(:,1,:), x(:,1:n2-1,:)-x(:,2:n2,:)]; %%\nabla_2^T y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Gvs = @(x) [cos(x),sin(x);-sin(x),cos(x)];  %%% Givens matrix

%%%%% edge- or coherence-structure tensor
if strcmpi(opts.reg1,'tensor') 
    sig = opts.ksig;   %%% mollifier_sigma
    rho = opts.krho;   %%% mollifier_rho
    EigInfo = coherence_orientation(x0,sig,rho);
    if strcmpi(opts.arrEnha,'edge')  %%%% Edge-enhancing
        Cpar = opts.EnCpar;
        lbd1 = 1-exp(-Cpar./(EigInfo.nu1.^2+eps));  lbd2 = 1;
        v1   = EigInfo.w1;  v2 = EigInfo.w2;   
    elseif strcmpi(opts.arrEnha,'cohere') %%%% Coherence-enhancing
        alp  = opts.Enalp; Cpar = opts.EnCpar;
        kap  = (EigInfo.nu1-EigInfo.nu2).^2;
        lbd1 = alp;         lbd2= alp+(1-alp)*exp(-Cpar./(kap+eps));
        v1   = EigInfo.w1;  v2 = EigInfo.w2;  
    else
        error('either [edge] or [cohere] enhance');
    end
%     [X,Y] = meshgrid(1:n1,1:n2);
%     nu1 =EigInfo.nu1; nu2 =EigInfo.nu2;
%     nu1([1:13,127:end],:)=0; nu1(:,[1:13,127:end])=0;
%     nu2([1:13,127:end],:)=0; nu2(:,[1:13,127:end])=0;
%     figure; imshow(1*ones(size(x0)),[],'border','tigh'); hold on;
%     tensor_field_representation(ones(size(x0)),v1,v2,nu1,nu2,X,Y,5,1); axis([0 n1 0 n2]); hold on      
%     figure; imshow(1*ones(size(x0)),[],'border','tigh'); hold on; 
%     tensor_field_representation(x0,v2,v1,lbd1,lbd2,X,Y,11,1); axis([0 n1 0 n2]);       
    clear EigInfo 
end

% figure(10); 
% subplot(221); imshow(lbd1); 
% title(['min:',num2str(min(lbd1(:))),'  max:',num2str(max(lbd1(:)))]);
% subplot(222); imshow(lbd2);
% title(['min:',num2str(min(lbd2(:))),'  max:',num2str(max(lbd2(:)))]);

% figure(20); subplot(221);  imshow(x0,[]); title('observed')

%%%%Intionalization
x   = x0;
xb  = x0;
y   = opts.y;
Lb  = [eps;eps;0]; Ub=[50;50;2*pi]; %%%% bounds on y
z   = zeros(n1,n2,n3);
q11 = zeros(n1,n2,n3);
q12 = zeros(n1,n2,n3);

PSNR = zeros(1,MaxIt);  
SSIM = zeros(1,MaxIt);  
RelErr = zeros(1,MaxIt);  
Time   = zeros(1,MaxIt);  
StopTol= zeros(1,MaxIt);
    

G    = Gvs(opts.ytrue(3)); 
Atrue= G*diag(opts.ytrue(1:2))*G';
G    = Gvs(y(3)); 
A    = G*diag(y(1:2))*G';
NAtrue=norm(Atrue(:));    
% [X1,X2] = meshgrid(linspace(-n2/2+1,n2/2,n2),linspace(-n1/2+1,n1/2,n1));
% X1=X1(:); X2=X2(:);
time0 = cputime;
for itr=1:MaxIt     
    
    %%%%%%%%% measurements: PSNR/SSIM/RelErr/Time %%%%%%%%%
    Time(itr) = cputime-time0;
    PSNR(itr) = psnr(x,opts.I);     %%% PSNR
%     if mod(itr,20)==0
    
    K = [0.05 0.05]; L = 1;  window = ones(16); 
    [mssim,~] = ssim_index(x,opts.I,K,window,L); %%% SSIM
    SSIM(itr) = mssim;
    RelErr(itr) = norm(Atrue(:)-A(:))/NAtrue;        
%     end
    if mod(itr,100)==0
        subplot(221);imshow(xb,[]);
        subplot(222); imshow(x,[]);
        title(['it',num2str(itr),'SSIM:',num2str(SSIM(itr))]);
        subplot(223); imshow(fftshift(Ay),[]); 
        title(['y=',num2str(y(1)),',',num2str(y(2)),',',num2str(y(3))]);
        drawnow
        subplot(224); spy(fftshift(Ay));
        fprintf('it=%3d,PSNR=%5.2f,SSIM=%6.4f,er(y)=%6.3f,det(A)=%4.2f\n',...
            itr,PSNR(itr),SSIM(itr),RelErr(itr),det(A))
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
     
    %%% step 1:  z
    G  = Gvs(y(3)); 
    A  = G*diag(y(1:2))*G';
    Ay = aniso_gaussian_kernel(A,[0,0],[n1,n2]); 
    tep= z + s(1)*(real(ifft2(fft2(Ay).*fft2(x)))-x0);
    if strcmpi(opts.FdT,'l1')      %%%% L1-norm fidelity
        zn = max(-1,min(tep,1));
    elseif strcmpi(opts.FdT,'l2')  %%%% L2-norm fidelity
        zn = tep/(1+s(1));
    elseif strcmpi(opts.FdT,'idv') %%%% I-divergence fidelity
        zn = 0.5*(x0+tep+1-sqrt((x0+tep-1).^2+4*s(1)*x0));
    end
    
    
    %%% step 2: q1
    if strcmpi(opts.reg1,'tensor')   %%%%% anisotropic tensor
        tep1 = q11+s(2)*tau1*Px(x);
        tep2 = q12+s(2)*tau1*Py(x);
        sk1  = lbd1.*(v1(:,:,1).*tep1 + v1(:,:,2).*tep2)./(lbd1+s(2)*tau1);
        sk2  = lbd2.*(v2(:,:,1).*tep1 + v2(:,:,2).*tep2)./(lbd2+s(2)*tau1);
        q11n = v1(:,:,1).*sk1+v2(:,:,1).*sk2;
        q12n = v1(:,:,2).*sk1+v2(:,:,2).*sk2;
    elseif strcmpi(opts.reg1,'tv')  %%% Total variation
        sk1  = q11+s(2)*tau1*Px(x);
        sk2  = q12+s(2)*tau1*Py(x);
        nsk  = sqrt(sk1.^2+sk2.^2+eps); 
        nsk  = min(1,1./nsk);
        q11n = nsk.*sk1;
        q12n = nsk.*sk2;
    else
        error('regularizer of x is missing!')
    end
    
    %%%%% extrapolation step (varrho=1)
    varrho = 0.6;
    zbar   = zn  + varrho*(zn-z);
    q11bar = q11n+ varrho*(q11n-q11);
    q12bar = q12n+ varrho*(q12n-q12);
    
    %%% step 3: x
    G  = Gvs(y(3)); 
    A  = G*diag(y(1:2))*G';
    Ay = aniso_gaussian_kernel(A,[0,0],[n1,n2]); 
    tep= real(ifft2(conj(fft2(Ay)).*fft2(zbar)))+tau1*(PTx(q11bar)+PTy(q12bar));
    xn = max(0,min(x-r(1)*tep,1)); %% projection [0,1]
    
    %%% step 4: y 
    ffx   = fft2(x);
    deltay= 0.001;
    ty    = 0*y;
    cy    = 0*y;
    for i = 1:length(y)
        yps  = y;   yps(i)= y(i)+deltay;
        G    = Gvs(yps(3)); 
        A    = G*diag(yps(1:2))*G';
        Ayps = aniso_gaussian_kernel(A,[0,0],[n1,n2]); 
        dAyps= (Ayps-Ay)/deltay; 
        tep  = real(ifft2(fft2(dAyps).*ffx));
        ty(i)= sum(sum(tep.*zbar));
        
        %%% for correction
        cy(i)= sum(sum(tep.*(z-zn)));
    end
    tep = (y-r(2)*ty)/(1+tau2*r(2));
    yn  = max(Lb,min(tep,Ub));
    
    StopTol(itr)=norm(x-xn,'fro')/norm(x,'fro');   
    % fprintf('stopping rule=%6.4f\n',StopTol(itr))
    
    %%% correction
    cx  = real(ifft2(conj(fft2(Ay)).*fft2(z-zn)))+tau1*(PTx(q11-q11n)+PTy(q12-q12n));
    xnew= xn+r(1)*(1-varrho)*cx;
    ynew= yn+r(2)*(1-varrho)*cy;
    q11 = q11n;
    q12 = q12n;
    z   = zn;
    
    
    x = xnew;
    y = ynew;
    
end
outs.It  = itr;
outs.x   = x; 
outs.PSNR= PSNR;
outs.SSIM= SSIM; 
outs.Ay  = Ay; 
outs.A   = A; 
outs.y   = y; 
outs.RelErr= RelErr;
outs.StopTol= StopTol;
outs.Time= Time;
  
