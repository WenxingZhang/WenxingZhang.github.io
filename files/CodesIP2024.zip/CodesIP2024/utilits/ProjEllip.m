function x = ProjEllip(A,r,b) 
% This codes use 4 methods to compute the projection onto n-D ellipsoid
% min \|x-b\|_2  s.t. \|x\|_A<=r
% Use the idea of trust-region subproblem
% For projection onto \|x-xc\|_A<=r, use: xsol = xc + Proj(b-xc)
% Written by Wenxing Zhang, zhangwx@uestc.edu.cn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Example  %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % n = 2; 
% % A = randn(n)+diag(80*rand(n,1)); A = (A+A')/2;
% % r = 5;   %%%% radius of ellips
% % xc =5*randn(n,1);
% % b = 10*randn(n,1); 
% % xsol = xc+ProjEllip(A,r,b-xc);
% % if length(b)==2||length(b)==3  %%% 
% %     figure; PlotEllip(A,xc,r); hold on
% %     if length(b)==2; plot([b(1),xsol(1)],[b(2),xsol(2)],'-r*'); end
% %     if length(b)==3; plot3([b(1),xsol(1)],[b(2),xsol(2)],[b(3),xsol(3)],'-r*'); end
% % end
% % axis equal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


MaxIt = 50; 
arr   = 'V2'; %% Default: V2 is very fast; other choice are not good
[V,D] = eig(A,'vector');
if ~issymmetric(A)|| min(D)<0; %%%% Check A symmetric positive definite
    error('A must be symmetric positive definite'); 
end

nu  = 0;    %%% initial point
VTb = V'*b; 
for itr = 1:MaxIt; 
    if b'*A*b<=r^2; x = b; break; end
    if strcmpi(arr,'V1')
        %%%%%%%%% root-finding on phi_1=|x(nu)|_A^2-r^2
        if itr == 1; xA_up = D.*(VTb.^2); end
        xA_low  = (1+nu*D).^2;
        xAnormSq= sum(xA_up./xA_low);
        phi     = xAnormSq - r^2;
        if itr==1; dphi_up = (-2)*(D.*VTb).^2; end
        dphi_low= (1+nu*D).^3;
        dphi    = sum(dphi_up./dphi_low);
        nupre   = nu;
        nu      = nu-phi/dphi;    
    elseif strcmpi(arr,'V2')
        %%%% root-finding on phi_2=1/|x(nu)|_A-1/r
        if itr==1; xA_up = D.*(VTb.^2);  end
        xA_low  = (1+nu*D).^2;
        xAnorm  = sqrt(sum(xA_up./xA_low));
        phi2    = 1/xAnorm - 1/r;
        if itr==1; dphi_up = (-2)*(D.*VTb).^2; end
        dphi_low= (1+nu*D).^3;
        dphi    = sum(dphi_up./dphi_low);
        dphi2   = -dphi/(2*xAnorm^3);
        nupre   = nu;
        nu      = nu-phi2/dphi2; 
    elseif strcmpi(arr,'cholV1')
        %%%%%%%%% root-finding on phi_1=|x(nu)|_A^2-r^2 + Cholsky
        IvA  = eye(size(A))+nu*A;
        arrpd.POSDEF=true;  arrpd.SYM=true;  x = linsolve(IvA,b,arrpd); 
        R    = chol(IvA);
        Ax   = A*x;
        arrtr.LT=true;  z = linsolve(R',Ax,arrtr);
        xAx  = x'*Ax;
        zN   = z'*z;
        nupre= nu;
        nu   = nu+(xAx-r^2)/(2*zN);        
    elseif strcmpi(arr,'cholV2')
        %%%% root-finding on phi_2=1/|x(nu)|_A-1/r + Cholsky
        IvA= eye(size(A))+nu*A;
        arrpd.POSDEF=true;  arrpd.SYM=true;  x = linsolve(IvA,b,arrpd); 
        Ax = A*x;
        xAx= x'*Ax;        
        R  = chol(IvA);
        arrtr.LT=true;  z = linsolve(R',Ax,arrtr);
        zN = z'*z;
        nupre=nu;
        nu = nu+xAx*(sqrt(xAx)-r)/(r*zN); 
    end    
    
    if abs(nu-nupre)<1e-12 
        fprintf('itr=%d, nu=%4.2f\n',itr,nu)
        x = (eye(size(A))+nu*A)\b;
        break;
    end
end
if itr == MaxIt 
    fprintf('solution at maximal iteration=%d\n',itr);
    x = (eye(size(A))+nu*A)\b;
end



