function PlotEllip(A,xc,r)
%%% This code plot the 2D/3D ellipsolid by
%%%   \|x-xc\|_A \leq r
%%% xc: center of ellipsolid (column vector)
%%%  A: symmetric  positive definite matrix
%%%  r: radius
%%% written by Wenxing Zhang, 2022.6.4

%%% example: 2D case
% A =[1/4,-1/25;-1/25 1/9]
% xc = [5;1];        %%%% center of ellips
% r = 1;            %%%% radius of ellips
% PlotEllip(A,xc,r)

%%% example: 3D case
% A =[1/4,-1/25,0;-1/25 1/9 0; 0 0 1/16]
% xc = [5;1;0];  %%%% center of ellips
% r = 1;            %%%% radius of ellips
% PlotEllip(A,xc,r) 

D = eig(A,'vector'); 
if ~issymmetric(A)|| min(D)<0; %%%% Check A symmetric positive definite
    error('A should be symmetric positive definite'); 
end


n = size(A,2);
R = chol(A);
if n==2 
    Npoint = 500;
    t   = linspace(0,2*pi,Npoint);
    temp= r*[cos(t);sin(t)];
    vert= bsxfun(@plus,R\temp,xc); 
    fill(vert(1,:),vert(2,:),'b','FaceAlpha',0.5,'linewidth',0.5); 
elseif n==3
    Npoint = 100;
    [x,y,z] = sphere(Npoint-1);
    temp= r*[x(:),y(:),z(:)]';
    vert= bsxfun(@plus,R\temp,xc);
%     vert= unique(vert','rows'); %% remove repetive or similar vertix
%     fac = convhulln(vert,{'Qt'}); 
x = reshape(vert(1,:),Npoint,Npoint);
y = reshape(vert(2,:),Npoint,Npoint);
z = reshape(vert(3,:),Npoint,Npoint);
    mesh(x,y,z,'FaceAlpha',0.8,'FaceColor','b',...
            'EdgeColor','r','linestyle','none','LineWidth',0.1)
        axis equal; view(3); camlight left; lighting phong; 
        material metal; grid on
else
    error('The code can only plot 2D/3D ellipoid')
end




