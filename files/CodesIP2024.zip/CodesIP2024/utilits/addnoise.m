function [nimg,index,Noise]=addnoise(img,type,r)
%%%%% Add impulsive noise to imge. 
%%%%% [nimg,ind] = addnoise(img,r,type)
%Input: img  -- original image (pixels must be scaled in [0, 1]).
%       r    -- the percentage of the impulse noise.
%       type -- type of impulsive noise. 
%                'sp': salt & pepper impulsive noise
%                'rv': random value impulse noise.
%output:nimg -- noised image
%       index-- location of noised pixel (1--noising,0--without noising)
%       Noise-- Actual impulsive noise 

[n,m] = size(img);
nimg  = img;
ran   = rand(n,m);

if strcmp(type,'sp')
    index1 = find(ran<=r/2);     nimg(index1) = 0;  %%% min pixel
    index2 = find(ran>=(1-r/2)); nimg(index2) = 1;  %%% max pixel
    index  = union(index1,index2); %%% All the noised pixels sets
    Noise  = zeros(n,m);  Noise(index2) = 1; %%% salt & pepper noise
elseif strcmp(type,'rv')
    index = find(ran<=r);
    Noise = rand(n,m);
    nimg(index) = Noise(index); 
else
    error('impulsive noise not correctly generated!');
end