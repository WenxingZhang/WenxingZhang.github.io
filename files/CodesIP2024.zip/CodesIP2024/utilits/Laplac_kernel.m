function gk=Laplac_kernel(S,mu,Nv)
% mulvariate gaussion kernel
%    p = exp[-0.5*(x-mu)^TS^{-1}(x-mu)] / sqrt{(2*pi)^k*det(S)}
% S ---covariance matrix (positive definite)
% mu --expectation gaussian 
% Nv --number of discrete point of gaussian function
% Written by Dr. Wenxing Zhang, UESTC, Chengdu, China

%%%1D example
% S=5; mu=15; Nv =50;  gk=aniso_gaussian_kernel(S,mu,Nv); 

% %%% 2D example
% sig1 = 6; sig2 =10; rho=0.1; %2D
% S=[sig1^2 rho*sig1*sig2; rho*sig1*sig2,sig2^2]; mu=[20,-10]; Nv =[128,256]; 
% gk=aniso_gaussian_kernel(S,mu,Nv);

% %%% 3D example
% sig1 = 8; sig2 =15; sig3 =13; rho=0; %2D
% S=[sig1^2,0 0; 0 sig2^2 0;  0 0 sig3^2]; mu=[3,-5,6]; Nv =[74,128,56]; 
% gk=aniso_gaussian_kernel(S,mu,Nv);


d  = size(S,1); %%% dimension of gaussian function
mu = mu(:); Nv = Nv(:); %%% transform into column vector
if d~=length(Nv) || d~=length(mu);
    error('dimension is not compate');  
end

%%%%%%%%%% 1D gaussian function
if det(S)<=1e-3;  S = 1e-3*eye(d);  end
A = inv(S);
if d==1 
    x1 = linspace(-Nv/2+1,Nv/2,Nv); 
    x = x1(:)-mu;    
end

%%%%%%%%%%2D gaussian function
if d==2 
    [x1,x2] = meshgrid(linspace(-Nv(2)/2+1,Nv(2)/2,Nv(2)),...
        linspace(-Nv(1)/2+1,Nv(1)/2,Nv(1)));   
    x = [x1(:)-mu(1),x2(:)-mu(2)];    
end

%%%%%%%%%% 3D gaussian function
if d==3 
    [x1,x2,x3] = meshgrid(linspace(-Nv(2)/2+1,Nv(2)/2,Nv(2)),...
        linspace(-Nv(1)/2+1,Nv(1)/2,Nv(1)),...
        linspace(-Nv(3)/2+1,Nv(3)/2,Nv(3)));
    x = [x1(:)-mu(1),x2(:)-mu(2),x3(:)-mu(3)];    
end

tep= sum((x*A).*x,2);
% gk = exp(0.5*tep) /sqrt((2*pi)^d*det(S));
gk = exp(-sqrt(2)*tep)./(tep.^(0.5)+0.01);  gk(gk<eps)=0; 
gk = gk/sum(gk(:));  % normalization
gk = reshape(gk,[Nv;1]');
gk = fftshift(gk);



%%%%%%%%%% plot figure
% if d==1; 
%     figure; plot(x1,fftshift(gk));
% end
% if d==2; 
%     figure; mesh(x1,x2,fftshift(gk)); 
%     xlabel('x1'); ylabel('x2');
% end
% if d==3; 
%     gk = fftshift(gk); 
%     er=2e-5; x1=x1(gk>er); x2=x2(gk>er); x3=x3(gk>er);
%     figure; plot3(x1(:),x2,x3,'.'); xlabel('x1');ylabel('x2');zlabel('x3');
% end




