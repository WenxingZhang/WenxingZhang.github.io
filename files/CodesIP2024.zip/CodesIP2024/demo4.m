%%% anisotropic (parametric) blind image deblurring 
%%% image formation: u0 = h_nu * u + eps
%%%  u0--observation, h_nu -- kernel with parameter nu (unknown)
%%%  u --ideal image, eps  -- noise
%%% model/reformulation as saddle point: Cao, et al, Inverse Problem, 2024
%%% codes written by Wenxing Zhang 
%%% UESTC, Chengdu, Sichuan, China, July 2022.
%%% Troubleshooting: zhangwx@uestc.edu.cn

% clc;
% clear;
% close all;
randn('state',0); rand('seed',0);
% addpath utilits solvers Images tensors
  

%% %%%% ideal image (u), ideal PSF's parameter (\nu) 
ImagName='shape.jpg';   ytrue = [7;5;pi/4]; 
I = im2double(imread(ImagName)); 

%% %%%%%% blurry (possibly noisy) image %%%%%%
Gvs = @(x) [cos(x),sin(x);-sin(x),cos(x)];   %% Givens transform
G   = Gvs(ytrue(3)); 
A   = G*diag(ytrue(1:2))*G';          %% anisotropy Gaussian
gk  = aniso_gaussian_kernel(A,[0,0],size(I));   
xh  = real(ifft2(fft2(gk).*fft2(I))); %% blurry image
NLg = 0.;       %% Gauss noise
NLi = 0.;       %% impulse noise
NoiseType='sp'; %% sp: salt-pepper; rv: random-valued 
xb  = addnoise(xh+NLg*randn(size(I)),NoiseType,NLi); %% noisy image

%% %%% settings: MaxIter, tensor name/scalars, tolerance, etc %%%
opts.MaxIt = 800;  opts.I = I;  opts.ytrue = ytrue;
opts.arrEnha = 'edge'; opts.EnCpar = 1e-10; opts.krho=0.5; opts.ksig=2;

% opts.arrEnha = 'cohere'; opts.EnCpar = 1e-9; opts.Enalp =1e-2; opts.krho=1; opts.ksig=1;

%% our method with various image priors and fidelities
%%%% [1] structure tensor + L2 fidelity
% opts.r =[1,0.1]; opts.s=[1,1];  
% opts.reg1='tensor';   opts.FdT = 'l2';  opts.y = [15;15;pi];
% opts.tau = [1e-4,1e-4]; outs = NLPDHG_StruTensorVer4(xb,opts);

%%%% [2] structure tensor + L1 fidelity
opts.r =[0.1,0.001]; opts.s=[10,10];  %%% tensor + L1
opts.reg1='tensor';   opts.FdT = 'l1';  opts.y = [10;10;pi];
opts.tau = [1e-5,1e-2]; outs = NLPDHG_StruTensorVer4(xb,opts);

%% %%%%%%%% plot evolutions of PSNR/SSIM/RelErr
close all
scrsz = get(groot,'ScreenSize');  
Sizfig= [scrsz(4)/2 scrsz(4)/5 scrsz(3)*0.35 scrsz(4)*0.45];
arr_data={'PSNR','SSIM','RelErr'};
figure('Position',Sizfig); 
for num = 1:3
    subplot(2,2,num)
    c = 1:1:opts.MaxIt; 
    plot(c,eval(['outs.',arr_data{num},'(c)']),'-r','linewidth',2.5,...
        'markerface','r','markersize',2); hold on 
    set(gca,'fontsize',8,'fontweight','bold'); grid on
    xlabel('Iteration  No.','fontsize',12,'fontweight','bold');
    ylabel(arr_data{num},'fontsize',12,'fontweight','bold'); 
end
 
%% show result
figure(20); 
subplot(221); imshow(xb,[]); title('observed')
subplot(222); imshow(outs.x,[]);   title('restored');
subplot(223); imshow(fftshift(outs.Ay),[]); title('PSF');
subplot(224); spy(fftshift(outs.Ay));  title('PSF zoom-view')
